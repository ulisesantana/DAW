var text = '';

(function() {
  crossingDOM(document.documentElement, text);
  document.getElementById('html').innerText = document.documentElement.outerHTML;
  alert(text);
})();

function crossingDOM(node,text) {
  if (node == null && !notATextNode(node)) return;
  writeCode(node.tagName);
  for (var i = 0; i < node.childNodes.length; i++) {
    crossingDOM(node.childNodes[i],text);
  }
}

function notATextNode(node) {
  return node.textContent.trim().length > 0 || node.nodeType != 3;
}

function writeCode(tagName){
  text += (tagName)
    ? '- ' + tagName + '\n'
    : '';
}
