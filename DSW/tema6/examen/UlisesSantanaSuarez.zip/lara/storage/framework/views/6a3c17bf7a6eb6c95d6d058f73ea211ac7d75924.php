<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<title>TEST</title>
		<style>
			.titulo { font-family:arial; font-size: 20px; color: #0022DD; font-weight: bold; }
			.boton { height: 24px; width: 100px; border-radius:2px 2px 2px 2px;
				    border:1px solid #0000FF; background: #0000DD; font-family: Arial;
				    font-size: 12px; color: #FFF; text-shadow: 0 1px #aa4040;
				    font-weight: bold; }
			.texto { font-family: verdana ; font-size: 14px; color: #0000DD; }
			.respuesta { font-family: verdana ; font-size: 14px; color: #000000; }
			.error { font-family: verdana ; font-size: 12px; color: red; }
      .facha{float:right;}
    </style>
	</head>
<body>
  <a class="facha" href="<?php echo e(url('logout')); ?>">Logout</a>
	<p class="titulo"> TEST </p>

	<hr align="left" width="340">
	<br>
  <h3>Hola <?php echo e($usuario); ?>, tu última nota fue un <?php echo e($nota); ?>%</h3>
	<form method="get" action="/test">
		<?php echo e(csrf_field()); ?>

		<table border="solid">
      <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr id="<?php echo e($pregunta->id); ?>">
         <td><?php echo e($pregunta->pregunta); ?></td>
         <td>
           V <input type="radio" name="respuesta<?php echo e($pregunta->id); ?>" value="V">
         </td>
         <td>
           F<input type="radio" name="respuesta<?php echo e($pregunta->id); ?>" value="F">
         </td>
       </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<tr height="80">
			  <td colspan="4" align="center">
					<input type="submit" name="enviar" value="ENVIAR" class="boton" style="width: 100px;">
			  </td>
			</tr>
		</table>
	</form>

</body>
</html>
