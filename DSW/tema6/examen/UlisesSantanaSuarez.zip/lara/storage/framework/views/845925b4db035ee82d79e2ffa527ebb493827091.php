<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<title>TEST</title>
		<style>
			.titulo { font-family:arial; font-size: 20px; color: #0022DD; font-weight: bold; }
			.boton { height: 24px; width: 100px; border-radius:2px 2px 2px 2px; 
				    border:1px solid #0000FF; background: #0000DD; font-family: Arial; 
				    font-size: 12px; color: #FFF; text-shadow: 0 1px #aa4040; 
				    font-weight: bold; }
			.texto { font-family: verdana ; font-size: 14px; color: #0000DD; }
			.respuesta { font-family: verdana ; font-size: 14px; color: #000000; }
			.error { font-family: verdana ; font-size: 12px; color: red; }
		</style>
	</head>
<body>
	<p class="titulo"> TEST </p> 

	<hr align="left" width="340">
	<br>
	
	<form method="get" action="/test">
		<?php echo e(csrf_field()); ?>

		<table width="340" class="texto">
			<?php 
			
				// PREGUNTAS DEL TEST
			
			?>
			<tr height="80">
			  <td colspan="3" align="center">
					<input type="submit" name="enviar" value="ENVIAR" class="boton" style="width: 100px;">
			  </td>
			</tr>
		</table>
	</form>
	
</body> 
</html>
